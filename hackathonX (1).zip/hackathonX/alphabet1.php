<?php  

  session_start()

  

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=h, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleAlphabet.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800&display=swap" rel="stylesheet">
    <title>الحروف</title>
    
    
</head>
    <script>
    var letter = document.getElementsByClassName("Circles yellow").name;
        if(letter = "c"){
            
        }
        else {
            location.href = "index.html";
        }
    
    
    </script>
<body>
   
    <div class="alphabet">
        <div>
            <h1>إختر الحرف</h1>
             </div>
        <form method="post" action="options.php">   
       
        <div class="alphabet-Circles">
            
            <div class="Circles yellow" onclick="window.location.href='options/options8.php'"><h2>د</h2></div>
            <div class="Circles blue" onclick="window.location.href='options/options7.php'"><h2>خ</h2></div>
            <div class="Circles yellow" onclick="window.location.href='options/options6.php'"><h2>ح</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options5.php'"><h2>ج</h2></div>
            <div name="d" class="Circles orange" onclick="window.location.href='options/options4.php'"><h2>ث</h2></div>
            <div name="c" class="Circles blue" onclick="window.location.href='options/options3.php'"><h2>ت</h2></div>
            <div name="b" class="Circles yellow" onclick="window.location.href='options/options2.php'"><h2>ب</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options1.php'"><h2>أ</h2></div>
            
            <div class="Circles orange" onclick="window.location.href='options/options16.php'"><h2>ط</h2></div>
            <div class="Circles blue" onclick="window.location.href='options/options15.php'"><h2>ض</h2></div>
            <div class="Circles orange" onclick="window.location.href='options/options14.php'"><h2>ص</h2></div>
            <div class="Circles blue" onclick="window.location.href='options/options13.php'"><h2>ش</h2></div>
            <div class="Circles yellow" onclick="window.location.href='options/options12.php'"><h2>س</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options11.php'"><h2>ز</h2></div>
            <div class="Circles orange" onclick="window.location.href='options/options10.php'"><h2>ر</h2></div>
            <div class="Circles blue" onclick="window.location.href='options/options9.php'"><h2>ذ</h2></div>
            
            
            <div class="Circles pink" onclick="window.location.href='options/options24.php'"><h2>م</h2></div>
            <div class="Circles yellow" onclick="window.location.href='options/options23.php'"><h2>ل</h2></div>
            <div class="Circles blue" onclick="window.location.href='options/options22.php'"><h2>ك</h2></div>
            <div class="Circles orange" onclick="window.location.href='options/options21.php'"><h2>ق</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options20.php'"><h2>ف</h2></div>
            <div class="Circles orange" onclick="window.location.href='options/options19.php'"><h2>غ</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options18.php'"><h2>ع</h2></div>
            <div class="Circles yellow" onclick="window.location.href='options/options17.php'"><h2>ظ</h2></div>
            
            <div id="right">
            <div class="Circles blue" onclick="window.location.href='options/options28.php'"><h2>ي</h2></div>
            <div class="Circles orange" onclick="window.location.href='options/options27.php'"><h2>و</h2></div>
            <div class="Circles pink" onclick="window.location.href='options/options26.php'"><h2>هـ</h2></div>
            <div class="Circles yellow" onclick="window.location.href='options/options25.php'"><h2>ن</h2></div>
                
        </div>
        </div>      

            
    
    </form>
        </div>
</body>
</html>