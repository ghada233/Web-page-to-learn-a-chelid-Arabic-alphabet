<html>
<head>
    
    <meta charset="UTF-16">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200;300;400;500;700;800&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="css/optionsStyle.css">

</head>
<body>
     <script>
    function move1(){
       location.href='quizzes/picsQuiz/picsquiz copy 14.html';
        
    }
         function move2(){
        location.href='quizzes/pronouncation/pronouncation copy 14.html';
        
    }
         function move3(){
        location.href='quizzes/uploadQuiz/uploadquiz copy14.html';
        
    }
         function move4(){
        location.href='quizzes/recognizeLetter/recognizeletter copy 14.html';
        
    }
      
    </script>
    
 <div id="box">
    <p id="q">قم باختيار التمرين</p>
     <div id="options">
     <div class="submit-button" onclick="move3()"><img class="imgs" src="img/test.png"></div>
     <div class="submit-button" onclick="move1()"><img class="imgs"src="img/photo.png"></div>
  
        <div class="submit-button" onclick="move4()"><img class="imgs"src="img/podcast.png"></div>
        <div class="submit-button" onclick="move2()"><img class="imgs"src="img/quiz.png"></div>
  
    </div>
         
         
    </div>
   </body> 
    
    </html>