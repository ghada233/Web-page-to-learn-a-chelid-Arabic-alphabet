<html>
<head>
    
    <meta charset="UTF-16">
    <link href="https://fonts.google.com/specimen/Tajawal#standard-styles">
    <link href="https://fonts.google.com/specimen/Amiri">
<style>
    
    #box {
        box-shadow: 5px 5px 5px 5px grey;
        width: 700px;
        height: 40em;
        position: relative;
        left: 25%;
        top: 10%;
        background: url("img/background.png")fixed;
        background-size:contain;
        
        
    }    
   
   
    
    .submit-button{
      
      font-size: 2rem;
      position: relative;
      top: 60%;
      left: 35%;
      width: 8rem;
      height: 7rem;
      border: none;
      border-radius: 12rem;
      color: #fff;
      background-color: #FFC300;
      cursor: pointer;
        margin-left: 2em;
  }
  .submit-button:hover{
    background-color: #CB9F08;
    -webkit-transition: .1s;
    -o-transition: .1s;
    transition: .1s;
  }
   
    #q{
        color: #FFC300;
        font: 30px Tajawal;
        text-align: center;
        position: relative;
        top: 5%;
    }
    #options {
        display: flex;
        flex-wrap: unwrap;
        justify-content: center;
        position: relative;
        top:15%;
        left: 30%;
        
        width: 7rem;
    }
    #options2 {
        position: relative;
        top:25%;
        right: 20%;
    }
    .submit-button, type {
        width: 70px;
        
    }
    
    
</style>
</head>
<body>
     <script>
    function move1(){
        location.href='/picsquiz.html';
        
    }
         function move2(){
        location.href='/pronouncation.html';
        
    }
         function move3(){
        location.href='/uploadquiz.html';
        
    }
         function move4(){
        location.href='/recognizeletter.html';
        
    }
      
    </script>
    
 <div id="box">
    <p id="q">قم باختيار التمرين</p>
     <div id="options">
  <input class="submit-button" type="image" src="img/test.png" onclick="move3()">
  <input class="submit-button" type="image" src="img/photo.png" onclick="move1()">
          </div>
         <div id="options2">
  <input class="submit-button"  id="1"type="image" src="img/quiz.png" onclick="move4()">
  <input class="submit-button"  id="2"type="image" src="img/podcast.png" onclick="move2()">
 </div>
         
    </div>
   </body> 
    
    </html>